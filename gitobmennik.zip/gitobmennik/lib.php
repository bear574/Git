<?php
session_start();
const DB_FILE = __DIR__ . '/data/site.sqlite';
function db(): PDO {
    static $pdo;
    if (!$pdo) {
        $pdo = new PDO('sqlite:' . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE COLLATE NOCASE, password_hash TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', filename TEXT NOT NULL, stored_name TEXT NOT NULL, file_size INTEGER NOT NULL DEFAULT 0, repo_url TEXT NOT NULL DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id,title), FOREIGN KEY(user_id) REFERENCES users(id))");
    }
    return $pdo;
}
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function current_user() {
    if (empty($_SESSION['user_id'])) return null;
    $s = db()->prepare("SELECT id, username FROM users WHERE id=?"); $s->execute([$_SESSION['user_id']]); return $s->fetch() ?: null;
}
function require_login(): array {
    $u = current_user(); if (!$u) { header('Location: login.php'); exit; } return $u;
}
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function check_csrf(): void { if (!hash_equals(csrf_token(), $_POST['csrf'] ?? '')) { http_response_code(403); exit('Ошибка проверки формы. Обновите страницу.'); } }
function project_by_id($id) { $s=db()->prepare("SELECT p.*,u.username FROM projects p JOIN users u ON u.id=p.user_id WHERE p.id=?"); $s->execute([(int)$id]); return $s->fetch(); }
function safe_upload_name($name): string { $name = basename(str_replace('\\','/',$name)); return preg_replace('/[\x00-\x1F\x7F]/u', '', $name) ?: 'file.bin'; }
