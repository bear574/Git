<?php
require __DIR__.'/lib.php'; $me=require_login(); $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 check_csrf(); $title=trim($_POST['title']??''); $desc=trim($_POST['description']??''); $url=trim($_POST['repo_url']??'');
 if ($title==='') $error='Укажи название проекта.';
 elseif (mb_strlen($title)>100) $error='Название слишком длинное (до 100 символов).';
 elseif ($url!=='' && !filter_var($url,FILTER_VALIDATE_URL)) $error='Ссылка должна быть полным URL.';
 elseif (empty($_FILES['file']) || $_FILES['file']['error']!==UPLOAD_ERR_OK) $error='Не удалось загрузить файл. Проверь лимиты PHP и сервера.';
 else {
   $f=$_FILES['file']; $max=50*1024*1024*1024;
   if ($f['size']>$max) $error='Файл больше 50 ГБ.';
   else {
    $dir=__DIR__.'/uploads'; if(!is_dir($dir)) mkdir($dir,0755,true);
    $stored=bin2hex(random_bytes(16)).'.bin'; $dest=$dir.'/'.$stored;
    if(move_uploaded_file($f['tmp_name'],$dest)) {
      try { $s=db()->prepare('INSERT INTO projects(user_id,title,description,filename,stored_name,file_size,repo_url) VALUES(?,?,?,?,?,?,?)'); $s->execute([$me['id'],$title,$desc,safe_upload_name($f['name']),$stored,(int)$f['size'],$url]); header('Location: profile.php'); exit; }
      catch(PDOException $e) { @unlink($dest); $error='У тебя уже есть проект с таким названием.'; }
    } else $error='Не получилось сохранить файл на сервере.';
   }
 }
}
?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Загрузить проект</title><link rel="stylesheet" href="style.css"></head><body><main class="narrow"><a href="profile.php">← Профиль</a><h1>Новый проект</h1><p class="muted">В этой простой версии загрузка идёт одним запросом. Для файлов до 50 ГБ сервер должен быть специально настроен; см. README.</p><?php if($error):?><p class="error"><?=h($error)?></p><?php endif;?><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>Название проекта<input name="title" required maxlength="100"></label><label>Описание<textarea name="description" rows="6"></textarea></label><label>Ссылка на другой репозиторий (необязательно)<input name="repo_url" type="url" placeholder="https://..."></label><label>Файл проекта<input type="file" name="file" required></label><button>Опубликовать</button></form></main></body></html>