<?php
require __DIR__.'/lib.php'; $p=project_by_id($_GET['id']??0); if(!$p){http_response_code(404);exit('Проект не найден');}
$file=__DIR__.'/uploads/'.$p['stored_name']; if(!is_file($file)){http_response_code(404);exit('Файл не найден');}
header('Content-Type: application/octet-stream'); header('Content-Disposition: attachment; filename*=UTF-8\'\''.rawurlencode($p['filename'])); header('Content-Length: '.filesize($file)); header('X-Content-Type-Options: nosniff'); readfile($file); exit;
