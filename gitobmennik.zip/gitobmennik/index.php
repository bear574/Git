<?php
require __DIR__ . '/lib.php';
$search = trim($_GET['q'] ?? '');
$author = trim($_GET['author'] ?? '');
$sql = "SELECT p.*, u.username FROM projects p JOIN users u ON u.id=p.user_id WHERE 1=1";
$args = [];
if ($search !== '') { $sql .= " AND p.title LIKE ?"; $args[] = "%$search%"; }
if ($author !== '') { $sql .= " AND u.username LIKE ?"; $args[] = "%$author%"; }
$sql .= " ORDER BY p.created_at DESC";
$stmt = db()->prepare($sql); $stmt->execute($args); $projects = $stmt->fetchAll();
?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Git-обменник</title><link rel="stylesheet" href="style.css"></head><body>
<header><a href="index.php"><b>Git-обменник</b></a><nav><?php if ($me = current_user()): ?><span>Привет, <?=h($me['username'])?></span> <a href="profile.php">Мои проекты</a> <a href="upload.php">Загрузить</a> <a href="logout.php">Выйти</a><?php else: ?><a href="login.php">Войти</a> <a href="register.php">Регистрация</a><?php endif; ?></nav></header>
<main><h1>Лента проектов</h1><form class="search" method="get"><input name="q" placeholder="Название проекта" value="<?=h($search)?>"><input name="author" placeholder="Имя автора" value="<?=h($author)?>"><button>Найти</button><a href="index.php">Сбросить</a></form>
<?php if (!$projects): ?><p>Ничего не найдено.</p><?php endif; ?>
<section class="list"><?php foreach ($projects as $p): ?><article><h2><a href="project.php?id=<?=$p['id']?>"><?=h($p['title'])?></a></h2><p class="muted">Автор: <?=h($p['username'])?> · <?=h($p['created_at'])?></p><p><?=nl2br(h($p['description']))?></p><p><a href="download.php?id=<?=$p['id']?>">Скачать файл</a> · <a href="project.php?id=<?=$p['id']?>">Подробнее</a></p></article><?php endforeach; ?></section></main></body></html>